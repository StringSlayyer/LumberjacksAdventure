***Note of the author***

NOTE: This font is for PERSONAL USE ONLY!  
   
 To purchase a commercial license, visit:  
 <http://mn.sg/kurri-island>  
   
 For questions, please visit [www.mn.sg/faq](http://www.mn.sg/faq)  
   
 Visit my website: <http://www.mansgreback.com>  
 Like my fonts on Facebook: <http://www.facebook.com/mansgreback>
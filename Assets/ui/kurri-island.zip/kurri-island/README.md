# Downloaded From FontGet.com
This font was downloaded for free from [FontGet.com](https://www.fontget.com/?utm_source=download&utm_medium=zip). To download more free fonts please visit [https://www.fontget.com](https://www.fontget.com/?utm_source=download&utm_medium=zip). 

If you would like instructions on how to install this font for your PC or Mac you can visit our helpful installation guide located at [https://www.fontget.com/help/](https://www.fontget.com/help/?utm_source=download&utm_medium=zip). 

**Please note:** FontGet.com is a website where users can upload and share fonts. We do not own the fonts in this package. Please check the `license.md` file to see what the licensing requirements are for this font. Some fonts require a commerical license directly from the author.